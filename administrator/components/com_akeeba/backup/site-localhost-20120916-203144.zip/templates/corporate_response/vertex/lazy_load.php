<script type="text/javascript">//<![CDATA[
	var s5_lazyload = "<?php echo $s5_lazyload; ?>";
//]]></script>
<script type="text/javascript" language="javascript" src="<?php echo $s5_directory_path ?>/js/lazy_load.js"></script>