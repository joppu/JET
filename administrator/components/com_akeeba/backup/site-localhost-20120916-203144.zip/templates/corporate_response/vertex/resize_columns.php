<script type="text/javascript">//<![CDATA[
	var s5_resize_columns = "<?php echo $s5_resize_columns; ?>";
	var s5_resize_columns_delay = "<?php echo $s5_resize_columns_delay; ?>";
	var s5_resize_columns_small_tablets = "<?php echo $s5_responsive_columns_small_tablet; ?>";
//]]></script>
<script type="text/javascript" language="javascript" src="<?php echo $s5_directory_path ?>/js/s5_columns_equalizer.js"></script>